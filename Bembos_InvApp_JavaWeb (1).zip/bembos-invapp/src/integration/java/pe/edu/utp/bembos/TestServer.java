package pe.edu.utp.bembos;
import org.apache.catalina.startup.Tomcat;
/** Servidor de prueba: despliega el WAR real con su web.xml y sus anotaciones. */
public class TestServer {
 public static void main(String[] args)throws Exception{
  Tomcat t=new Tomcat();t.setBaseDir("target/test-tomcat");t.setPort(18080);t.getConnector();
  t.addWebapp("/bembos-invapp",new java.io.File("target/bembos-invapp.war").getAbsolutePath());
  t.start();t.getServer().await();
 }
}
