package pe.edu.utp.bembos.model;
import java.io.Serializable;
public record UsuarioSesion(String id,String nombre,String correo,String rol,String tienda) implements Serializable {}