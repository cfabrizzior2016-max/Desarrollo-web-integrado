package pe.edu.utp.bembos.service;
import pe.edu.utp.bembos.config.Conexion;
import pe.edu.utp.bembos.dao.InventarioDAO;
import pe.edu.utp.bembos.dao.ProductoDAO;
import pe.edu.utp.bembos.model.Producto;
import pe.edu.utp.bembos.model.UsuarioSesion;
import com.google.gson.*;
import java.sql.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

public final class InventarioService {
 private final InventarioDAO dao=new InventarioDAO();
 private final ProductoDAO productoDAO=new ProductoDAO();
 private final Gson gson=new Gson();
 public UsuarioSesion login(String email,String password)throws SQLException{
  try(Connection c=Conexion.getConexion()){
   var row=dao.one(c,"SELECT u.*,r.nombre rol FROM usuario u JOIN rol r ON r.id=u.rol_id WHERE u.correo=? AND u.activo=TRUE",email);
   if(row==null||!SeguridadContrasena.verify(password,String.valueOf(row.get("password_hash"))))throw new ErrorNegocio(401,"Credenciales incorrectas");
   return new UsuarioSesion(str(row,"id"),str(row,"nombre"),str(row,"correo"),str(row,"rol"),str(row,"tienda_id"));
  }
 }
 public Object read(String route,UsuarioSesion u,String id,String desde,String hasta)throws SQLException{
  try(Connection c=Conexion.getConexion()){
   return switch(route){
    case "/productos" -> productoDAO.listar(c);
    case "/lotes" -> dao.list(c,"SELECT l.*,p.nombre,p.unidad,p.stock_minimo,p.activo FROM lote l JOIN producto p ON p.id=l.producto_id WHERE l.tienda_id=? ORDER BY p.nombre,l.codigo",u.tienda());
    case "/turnos" -> dao.list(c,"SELECT * FROM turno WHERE tienda_id=? AND estado='ABIERTO'",u.tienda());
    case "/conteos" -> dao.list(c,"SELECT c.*,u.nombre usuario,t.estado estado_turno,(SELECT SUM(ABS(diferencia)) FROM detalle_conteo d WHERE d.conteo_id=c.id) diferencia_total FROM conteo c JOIN turno t ON t.id=c.turno_id JOIN usuario u ON u.id=c.usuario_id WHERE t.tienda_id=? ORDER BY c.fecha DESC,c.id LIMIT 200",u.tienda());
    case "/detalle" -> dao.list(c,"SELECT d.*,p.nombre,p.unidad,l.codigo FROM detalle_conteo d JOIN lote l ON l.id=d.lote_id JOIN producto p ON p.id=l.producto_id JOIN conteo co ON co.id=d.conteo_id JOIN turno t ON t.id=co.turno_id WHERE d.conteo_id=? AND t.tienda_id=? ORDER BY p.nombre",id,u.tienda());
    case "/mermas" -> dao.list(c,"SELECT m.*,p.nombre,l.codigo,u.nombre usuario FROM merma m JOIN lote l ON l.id=m.lote_id JOIN producto p ON p.id=l.producto_id JOIN usuario u ON u.id=m.usuario_id WHERE l.tienda_id=? ORDER BY m.fecha DESC LIMIT 200",u.tienda());
    case "/alertas" -> alerts(c,u);
    case "/historial" -> {role(u,"ADMINISTRADOR","JEFE_TIENDA");LocalDate from=date(desde),to=date(hasta);if(to.isBefore(from))throw new ErrorNegocio(400,"Rango de fechas inválido");yield dao.list(c,"SELECT h.id,h.entidad,h.id_entidad,h.operacion,h.antes,h.despues,h.fecha,u.nombre usuario FROM historial_operaciones h JOIN usuario u ON u.id=h.usuario_id WHERE u.tienda_id=? AND h.fecha>=? AND h.fecha<? ORDER BY h.fecha DESC LIMIT 200",u.tienda(),from.toString(),to.plusDays(1).toString());}
    default -> throw new ErrorNegocio(404,"Ruta no encontrada");
   };
  }
 }
 private Object alerts(Connection c,UsuarioSesion u)throws SQLException{
  var rows=dao.list(c,"SELECT p.nombre,'STOCK' tipo,CONCAT('Stock total: ',SUM(l.stock_actual),' ',p.unidad,'; mínimo: ',p.stock_minimo) mensaje FROM lote l JOIN producto p ON p.id=l.producto_id WHERE l.tienda_id=? AND p.activo=TRUE GROUP BY p.id,p.nombre,p.unidad,p.stock_minimo HAVING SUM(l.stock_actual)<=p.stock_minimo",u.tienda());
  rows.addAll(dao.list(c,"SELECT p.nombre,'VENCIMIENTO' tipo,CONCAT('Lote ',l.codigo,' vence el ',l.fecha_vencimiento) mensaje FROM lote l JOIN producto p ON p.id=l.producto_id WHERE l.tienda_id=? AND l.stock_actual>0 AND l.fecha_vencimiento<=DATE_ADD(CURDATE(),INTERVAL 7 DAY)",u.tienda()));
  rows.addAll(dao.list(c,"SELECT p.nombre,a.tipo,a.mensaje FROM alerta a JOIN lote l ON l.id=a.lote_id JOIN producto p ON p.id=l.producto_id WHERE l.tienda_id=? AND a.estado='PENDIENTE'",u.tienda()));return rows;
 }
 public Object mutate(String route,UsuarioSesion u,JsonObject b)throws SQLException{
  try(Connection c=Conexion.getConexion()){
   c.setAutoCommit(false);
   try{
    Object result=switch(route){
     case "/productos" -> product(c,u,b);
     case "/lotes" -> lot(c,u,b);
     case "/turnos" -> open(c,u);
     case "/conteos" -> count(c,u,b);
     case "/mermas" -> waste(c,u,b);
     case "/cierres" -> close(c,u,b);
     default -> throw new ErrorNegocio(404,"Ruta no encontrada");
    };c.commit();return result;
   }catch(SQLException|RuntimeException ex){c.rollback();throw ex;}
  }
 }
 private Object product(Connection c,UsuarioSesion u,JsonObject b)throws SQLException {
  role(u,"ADMINISTRADOR");String name=text(b,"nombre",100),cat=text(b,"categoria",50),unit=text(b,"unidad",20);BigDecimal min=quantity(b,"stock_minimo",false);
  String id=b.has("id")?text(b,"id",36):uuid();Producto before=productoDAO.obtener(c,id);
  Producto product=new Producto(id,name,cat,unit,min,true,1);
  if(before==null){if(b.has("id"))throw new ErrorNegocio(404,"Insumo no encontrado");productoDAO.crear(c,product);}
  else {product.setVersion(b.get("version").getAsInt());product.setActivo(b.get("activo").getAsBoolean());if(productoDAO.actualizar(c,product)!=1)throw new ErrorNegocio(409,"Otro usuario modificó el insumo; recarga");}
  audit(c,u,"PRODUCTO",id,before,b);return Map.of("id",id);
 }
 private Object lot(Connection c,UsuarioSesion u,JsonObject b)throws SQLException{
  role(u,"ADMINISTRADOR");String product=text(b,"producto_id",36),code=text(b,"codigo",50);LocalDate expiry=date(text(b,"fecha_vencimiento",10));BigDecimal stock=quantity(b,"stock_actual",false);
  lockStore(c,u);if(dao.one(c,"SELECT id FROM producto WHERE id=? AND activo=TRUE FOR UPDATE",product)==null)throw new ErrorNegocio(400,"Insumo inactivo o inexistente");
  String id=uuid();dao.update(c,"INSERT INTO lote(id,producto_id,tienda_id,codigo,fecha_vencimiento,stock_actual) VALUES (?,?,?,?,?,?)",id,product,u.tienda(),code,expiry.toString(),stock);audit(c,u,"LOTE",id,null,b);return Map.of("id",id);
 }
 private void lockStore(Connection c,UsuarioSesion u)throws SQLException{dao.one(c,"SELECT id FROM tienda WHERE id=? FOR UPDATE",u.tienda());}
 private Object open(Connection c,UsuarioSesion u)throws SQLException{
  role(u,"ADMINISTRADOR","JEFE_TIENDA");lockStore(c,u);var old=dao.one(c,"SELECT id FROM turno WHERE tienda_id=? AND estado='ABIERTO'",u.tienda());if(old!=null)return old;
  String id=uuid();dao.update(c,"INSERT INTO turno(id,tienda_id) VALUES (?,?)",id,u.tienda());audit(c,u,"TURNO",id,null,Map.of("estado","ABIERTO"));return Map.of("id",id);
 }
 private Map<String,Object> turno(Connection c,UsuarioSesion u,JsonObject b)throws SQLException{
  lockStore(c,u);String id=text(b,"turno_id",36);var row=dao.one(c,"SELECT * FROM turno WHERE id=? AND tienda_id=? FOR UPDATE",id,u.tienda());if(row==null)throw new ErrorNegocio(404,"Turno no encontrado en tu tienda");return row;
 }
 private void checkOpen(Map<String,Object> turn){if(!"ABIERTO".equals(turn.get("estado")))throw new ErrorNegocio(409,"El turno ya está cerrado");}
 private String requestId(JsonObject b){String id=text(b,"id",36);try{UUID.fromString(id);}catch(Exception ex){throw new ErrorNegocio(400,"ID de operación inválido");}return id;}
 private boolean repeated(Connection c,UsuarioSesion u,String entity,String id,JsonObject body)throws SQLException{
  var old=dao.one(c,"SELECT usuario_id,despues FROM historial_operaciones WHERE entidad=? AND id_entidad=?",entity,id);
  if(old==null)return false;
  if(!u.id().equals(old.get("usuario_id"))||!JsonParser.parseString(str(old,"despues")).equals(body))throw new ErrorNegocio(409,"El ID ya fue usado con otros datos");return true;
 }
 private Object waste(Connection c,UsuarioSesion u,JsonObject b)throws SQLException{
  var turn=turno(c,u,b);String id=requestId(b);if(repeated(c,u,"MERMA",id,b))return Map.of("id",id,"repetida",true);checkOpen(turn);
  String lot=text(b,"lote_id",36),reason=text(b,"motivo",50),obs=optional(b,"observacion",300);BigDecimal qty=quantity(b,"cantidad",true);
  var row=dao.one(c,"SELECT * FROM lote WHERE id=? AND tienda_id=? FOR UPDATE",lot,u.tienda());if(row==null)throw new ErrorNegocio(404,"Lote no encontrado");
  BigDecimal stock=(BigDecimal)row.get("stock_actual");if(qty.compareTo(stock)>0)throw new ErrorNegocio(409,"La merma supera el stock disponible");
  dao.update(c,"UPDATE lote SET stock_actual=stock_actual-?,version=version+1 WHERE id=?",qty,lot);
  dao.update(c,"INSERT INTO merma(id,turno_id,usuario_id,lote_id,cantidad,motivo,observacion) VALUES (?,?,?,?,?,?,?)",id,turn.get("id"),u.id(),lot,qty,reason,obs);
  audit(c,u,"MERMA",id,null,b);return Map.of("id",id);
 }
 private Object count(Connection c,UsuarioSesion u,JsonObject b)throws SQLException{
  var turn=turno(c,u,b);String id=requestId(b);if(repeated(c,u,"CONTEO",id,b))return Map.of("id",id,"repetida",true);checkOpen(turn);
  if(dao.one(c,"SELECT id FROM conteo WHERE turno_id=? AND estado='ENVIADO'",turn.get("id"))!=null)throw new ErrorNegocio(409,"Existe un conteo pendiente de revisión en este turno");
  var details=b.getAsJsonArray("detalles");if(details==null||details.isEmpty()||details.size()>1000)throw new ErrorNegocio(400,"Debes enviar entre 1 y 1000 lotes");
  var lots=dao.list(c,"SELECT l.* FROM lote l JOIN producto p ON p.id=l.producto_id WHERE l.tienda_id=? AND p.activo=TRUE ORDER BY l.id FOR UPDATE",u.tienda());
  Map<String,Map<String,Object>> byId=new HashMap<>();for(var l:lots)byId.put(str(l,"id"),l);
  if(details.size()!=lots.size())throw new ErrorNegocio(409,"Debes contar todos los lotes activos; recarga el inventario");
  Set<String> seen=new HashSet<>();dao.update(c,"INSERT INTO conteo(id,turno_id,usuario_id) VALUES (?,?,?)",id,turn.get("id"),u.id());
  for(JsonElement el:details){JsonObject d=el.getAsJsonObject();String lot=text(d,"lote_id",36);var l=byId.get(lot);
   if(l==null||!seen.add(lot))throw new ErrorNegocio(400,"Lote inválido o duplicado");
   if(d.get("version").getAsInt()!=((Number)l.get("version")).intValue())throw new ErrorNegocio(409,"El stock cambió durante el conteo; recarga");
   BigDecimal qty=quantity(d,"cantidad_contada",false),stock=(BigDecimal)l.get("stock_actual");
   dao.update(c,"INSERT INTO detalle_conteo(id,conteo_id,lote_id,cantidad_registrada,cantidad_contada,version_lote) VALUES (?,?,?,?,?,?)",uuid(),id,lot,stock,qty,l.get("version"));
   if(qty.compareTo(stock)!=0)dao.update(c,"INSERT INTO alerta(id,lote_id,conteo_id,tipo,mensaje) VALUES (?,?,?,'DIFERENCIA',?)",uuid(),lot,id,"Diferencia de conteo: "+qty.subtract(stock).toPlainString());
  }audit(c,u,"CONTEO",id,null,b);return Map.of("id",id);
 }
 private Object close(Connection c,UsuarioSesion u,JsonObject b)throws SQLException{
  role(u,"ADMINISTRADOR","JEFE_TIENDA");lockStore(c,u);String id=text(b,"conteo_id",36),decision=text(b,"estado",20),obs=optional(b,"observacion",300);
  if(!Set.of("APROBADO","OBSERVADO").contains(decision))throw new ErrorNegocio(400,"Decisión inválida");if(decision.equals("OBSERVADO")&&obs.isBlank())throw new ErrorNegocio(400,"Escribe el motivo del rechazo");
  var count=dao.one(c,"SELECT c.* FROM conteo c JOIN turno t ON t.id=c.turno_id WHERE c.id=? AND t.tienda_id=? FOR UPDATE",id,u.tienda());
  if(count==null)throw new ErrorNegocio(404,"Conteo no encontrado");if(!"ENVIADO".equals(count.get("estado")))throw new ErrorNegocio(409,"Este conteo ya fue revisado");
  var turn=dao.one(c,"SELECT * FROM turno WHERE id=? FOR UPDATE",count.get("turno_id"));checkOpen(turn);
  var details=dao.list(c,"SELECT d.*,l.version,l.stock_actual FROM detalle_conteo d JOIN lote l ON l.id=d.lote_id WHERE d.conteo_id=? ORDER BY l.id FOR UPDATE",id);
  if(decision.equals("APROBADO")){
   // También detecta lotes añadidos/desactivados desde que se registró el conteo.
   var current=dao.list(c,"SELECT l.id FROM lote l JOIN producto p ON p.id=l.producto_id WHERE l.tienda_id=? AND p.activo=TRUE ORDER BY l.id FOR UPDATE",u.tienda());
   Set<String> counted=new HashSet<>();for(var d:details)counted.add(str(d,"lote_id"));
   if(current.size()!=counted.size()||current.stream().anyMatch(l->!counted.contains(str(l,"id"))))throw new ErrorNegocio(409,"El catálogo de lotes cambió. Observa el conteo y registra uno nuevo");
   for(var d:details){if(((Number)d.get("version_lote")).intValue()!=((Number)d.get("version")).intValue())throw new ErrorNegocio(409,"Hubo movimientos después del conteo. Observa el conteo y registra uno nuevo");
    dao.update(c,"UPDATE lote SET stock_actual=?,version=version+1 WHERE id=?",d.get("cantidad_contada"),d.get("lote_id"));
   }
   dao.update(c,"UPDATE turno SET estado='CERRADO',fin=CURRENT_TIMESTAMP WHERE id=?",turn.get("id"));
  }
  dao.update(c,"UPDATE conteo SET estado=? WHERE id=?",decision,id);dao.update(c,"UPDATE alerta SET estado='ATENDIDA' WHERE conteo_id=?",id);
  String closure=uuid();dao.update(c,"INSERT INTO cierre_inventario(id,conteo_id,jefe_id,estado,observacion) VALUES (?,?,?,?,?)",closure,id,u.id(),decision,obs);audit(c,u,"CIERRE",closure,count,b);return Map.of("id",closure);
 }
 private void audit(Connection c,UsuarioSesion u,String entity,String id,Object before,Object after)throws SQLException{dao.update(c,"INSERT INTO historial_operaciones(id,usuario_id,entidad,id_entidad,operacion,antes,despues) VALUES (?,?,?,?,?,?,?)",uuid(),u.id(),entity,id,before==null?"CREAR":"ACTUALIZAR",before==null?null:gson.toJson(before),gson.toJson(after));}
 public static String text(JsonObject b,String key,int max){if(!b.has(key)||b.get(key).isJsonNull()||!b.get(key).isJsonPrimitive())throw new ErrorNegocio(400,"Falta el campo "+key);String s=b.get(key).getAsString().strip();if(s.isEmpty()||s.length()>max)throw new ErrorNegocio(400,"Campo inválido: "+key);return s;}
 private String optional(JsonObject b,String key,int max){if(!b.has(key)||b.get(key).isJsonNull())return "";String s=b.get(key).getAsString().strip();if(s.length()>max)throw new ErrorNegocio(400,"Texto demasiado largo: "+key);return s;}
 public static BigDecimal quantity(JsonObject b,String key,boolean positive){BigDecimal n;try{n=b.get(key).getAsBigDecimal();}catch(Exception ex){throw new ErrorNegocio(400,"Cantidad inválida: "+key);}if(n.scale()>3||n.compareTo(new BigDecimal("999999999.999"))>0||n.signum()<0||(positive&&n.signum()==0))throw new ErrorNegocio(400,"Cantidad fuera de rango: "+key);return n;}
 public static LocalDate date(String s){try{return LocalDate.parse(s);}catch(Exception ex){throw new ErrorNegocio(400,"Fecha inválida");}}
 public static void role(UsuarioSesion u,String... roles){if(!Arrays.asList(roles).contains(u.rol()))throw new ErrorNegocio(403,"Tu rol no tiene permiso para esta operación");}
 private static String str(Map<String,Object> m,String key){return String.valueOf(m.get(key));}
 private static String uuid(){return UUID.randomUUID().toString();}
}
