package pe.edu.utp.bembos.service;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.*;
import java.util.*;
public final class SeguridadContrasena {
 private SeguridadContrasena(){}
 public static boolean verify(String password,String encoded){
  try{String[] a=encoded.split("\\$");if(a.length!=4||!a[0].equals("pbkdf2"))return false;
   int iterations=Integer.parseInt(a[1]);if(iterations<100000||iterations>2000000)return false;
   PBEKeySpec spec=new PBEKeySpec(password.toCharArray(),Base64.getDecoder().decode(a[2]),iterations,256);
   byte[] hash=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();spec.clearPassword();
   return MessageDigest.isEqual(hash,Base64.getDecoder().decode(a[3]));
  }catch(Exception ex){return false;}
 }
}