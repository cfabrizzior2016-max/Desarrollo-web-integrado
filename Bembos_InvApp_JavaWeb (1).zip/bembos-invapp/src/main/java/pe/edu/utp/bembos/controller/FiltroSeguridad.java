package pe.edu.utp.bembos.controller;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
@WebFilter("/*") public class FiltroSeguridad implements Filter {
 public void doFilter(ServletRequest q,ServletResponse r,FilterChain c)throws IOException,ServletException{
  var p=(HttpServletResponse)r;p.setHeader("X-Content-Type-Options","nosniff");p.setHeader("Referrer-Policy","same-origin");p.setHeader("X-Frame-Options","DENY");
  p.setHeader("Content-Security-Policy","default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");c.doFilter(q,r);
 }
}
