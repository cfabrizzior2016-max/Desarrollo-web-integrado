package pe.edu.utp.bembos.model;
import java.math.BigDecimal;
import com.google.gson.annotations.SerializedName;
/** Insumo del catálogo central. Las cantidades conservan tres decimales. */
public class Producto {
 private String id,nombre,categoria,unidad;
 @SerializedName("stock_minimo") private BigDecimal stockMinimo;
 private boolean activo;
 private int version;
 public Producto() {}
 public Producto(String id,String nombre,String categoria,String unidad,BigDecimal stockMinimo,boolean activo,int version){this.id=id;this.nombre=nombre;this.categoria=categoria;this.unidad=unidad;this.stockMinimo=stockMinimo;this.activo=activo;this.version=version;}
 public String getId(){return id;} public void setId(String v){id=v;}
 public String getNombre(){return nombre;} public void setNombre(String v){nombre=v;}
 public String getCategoria(){return categoria;} public void setCategoria(String v){categoria=v;}
 public String getUnidad(){return unidad;} public void setUnidad(String v){unidad=v;}
 public BigDecimal getStockMinimo(){return stockMinimo;} public void setStockMinimo(BigDecimal v){stockMinimo=v;}
 public boolean isActivo(){return activo;} public void setActivo(boolean v){activo=v;}
 public int getVersion(){return version;} public void setVersion(int v){version=v;}
}
