package pe.edu.utp.bembos.service;
public class ErrorNegocio extends RuntimeException {public final int status;public ErrorNegocio(int status,String message){super(message);this.status=status;}}