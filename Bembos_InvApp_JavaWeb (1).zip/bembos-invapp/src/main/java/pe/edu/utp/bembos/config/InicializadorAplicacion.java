package pe.edu.utp.bembos.config;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebListener;
@WebListener public class InicializadorAplicacion implements ServletContextListener {
 public void contextInitialized(ServletContextEvent e){try{Conexion.start();}catch(Exception ex){throw new IllegalStateException("No se pudo cargar la configuración",ex);}}
 public void contextDestroyed(ServletContextEvent e){Conexion.stop();}
}