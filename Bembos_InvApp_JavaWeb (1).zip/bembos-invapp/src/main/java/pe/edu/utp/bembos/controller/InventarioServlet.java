package pe.edu.utp.bembos.controller;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import pe.edu.utp.bembos.service.*;
import pe.edu.utp.bembos.model.UsuarioSesion;
import com.google.gson.*;
import java.io.*;
import java.sql.SQLException;
import java.util.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

@WebServlet("/api/*") public class InventarioServlet extends HttpServlet {
 private final Gson gson=new Gson();private final InventarioService service=new InventarioService();
 protected void doGet(HttpServletRequest q,HttpServletResponse p)throws IOException{dispatch(q,p,false);}
 protected void doPost(HttpServletRequest q,HttpServletResponse p)throws IOException{dispatch(q,p,true);}
 private void dispatch(HttpServletRequest q,HttpServletResponse p,boolean write)throws IOException{
  q.setCharacterEncoding("UTF-8");p.setContentType("application/json;charset=UTF-8");p.setHeader("Cache-Control","no-store");
  String route=q.getPathInfo()==null?"/me":q.getPathInfo();
  try{
   HttpSession session=q.getSession(true);String csrf=(String)session.getAttribute("csrf");if(csrf==null){csrf=UUID.randomUUID().toString();session.setAttribute("csrf",csrf);}
   if(write){String given=q.getHeader("X-CSRF-Token");if(given==null||!MessageDigest.isEqual(csrf.getBytes(StandardCharsets.UTF_8),given.getBytes(StandardCharsets.UTF_8)))throw new ErrorNegocio(403,"Sesión caducada; recarga la página");}
   UsuarioSesion user=(UsuarioSesion)session.getAttribute("user");
   if(!write&&route.equals("/me")){json(p,200,Map.of("csrf",csrf,"usuario",user==null?JsonNull.INSTANCE:user));return;}
   if(write&&route.equals("/login")){
    JsonObject b=body(q);user=service.login(InventarioService.text(b,"correo",150),InventarioService.text(b,"password",200));q.changeSessionId();session.setAttribute("user",user);session.setAttribute("csrf",UUID.randomUUID().toString());json(p,200,Map.of("usuario",user,"csrf",session.getAttribute("csrf")));return;
   }
   if(user==null)throw new ErrorNegocio(401,"Debes iniciar sesión");
   if(write&&route.equals("/logout")){session.invalidate();json(p,200,Map.of("ok",true));return;}
   Object result=write?service.mutate(route,user,body(q)):service.read(route,user,q.getParameter("id"),q.getParameter("desde"),q.getParameter("hasta"));json(p,200,result);
  }catch(ErrorNegocio ex){json(p,ex.status,Map.of("error",ex.getMessage()));}
   catch(SQLException ex){getServletContext().log("Error de base de datos",ex);if("23000".equals(ex.getSQLState()))json(p,409,Map.of("error","Datos duplicados o referencias inválidas"));else json(p,503,Map.of("error","No se pudo completar la operación de base de datos. Revisa la configuración del servidor"));}
   catch(IllegalStateException|IllegalArgumentException|NullPointerException ex){json(p,400,Map.of("error","Solicitud inválida; revisa los campos"));}
 }
 private JsonObject body(HttpServletRequest q)throws IOException{
  if(q.getContentType()==null||!q.getContentType().startsWith("application/json"))throw new ErrorNegocio(415,"Envía application/json");
  StringBuilder data=new StringBuilder();char[] buffer=new char[4096];try(var in=q.getReader()){int n;while((n=in.read(buffer))!=-1){data.append(buffer,0,n);if(data.length()>262144)throw new ErrorNegocio(413,"Solicitud demasiado grande");}}
  try{return JsonParser.parseString(data.toString()).getAsJsonObject();}catch(JsonParseException|IllegalStateException ex){throw new ErrorNegocio(400,"JSON inválido");}
 }
 private void json(HttpServletResponse p,int code,Object data)throws IOException{p.setStatus(code);p.getWriter().write(gson.toJson(data));}
}
