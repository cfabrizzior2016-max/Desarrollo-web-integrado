package pe.edu.utp.bembos.dao;
import java.sql.*;
import java.util.*;
/** DAO JDBC: SQL fijo en servicios; los valores siempre se enlazan. No recibe SQL del cliente. */
public final class InventarioDAO {
 public List<Map<String,Object>> list(Connection c,String sql,Object... args)throws SQLException{
  try(PreparedStatement p=c.prepareStatement(sql)){bind(p,args);try(ResultSet rs=p.executeQuery()){
   List<Map<String,Object>> rows=new ArrayList<>();var m=rs.getMetaData();
   while(rs.next()){Map<String,Object> row=new LinkedHashMap<>();for(int i=1;i<=m.getColumnCount();i++){Object v=rs.getObject(i);row.put(m.getColumnLabel(i),v instanceof java.sql.Date||v instanceof Timestamp?v.toString():v);}rows.add(row);}return rows;
  }}
 }
 public Map<String,Object> one(Connection c,String sql,Object... args)throws SQLException{var a=list(c,sql,args);return a.isEmpty()?null:a.getFirst();}
 public int update(Connection c,String sql,Object... args)throws SQLException{try(PreparedStatement p=c.prepareStatement(sql)){bind(p,args);return p.executeUpdate();}}
 private void bind(PreparedStatement p,Object[] args)throws SQLException{p.setQueryTimeout(10);for(int i=0;i<args.length;i++)p.setObject(i+1,args[i]);}
}