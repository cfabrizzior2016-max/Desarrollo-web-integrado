package pe.edu.utp.bembos.dao;
import java.sql.*;
import java.util.*;
import pe.edu.utp.bembos.model.Producto;
/** DAO tipado. La conexión pertenece a la transacción del servicio. */
public class ProductoDAO {
 public List<Producto> listar(Connection cn)throws SQLException {
  List<Producto> list=new ArrayList<>();try(PreparedStatement ps=cn.prepareStatement("SELECT * FROM producto ORDER BY nombre")){ps.setQueryTimeout(10);try(ResultSet rs=ps.executeQuery()){while(rs.next())list.add(mapear(rs));}}return list;
 }
 public Producto obtener(Connection cn,String id)throws SQLException {
  try(PreparedStatement ps=cn.prepareStatement("SELECT * FROM producto WHERE id=? FOR UPDATE")){ps.setQueryTimeout(10);ps.setString(1,id);try(ResultSet rs=ps.executeQuery()){return rs.next()?mapear(rs):null;}}
 }
 public int crear(Connection cn,Producto p)throws SQLException {
  try(PreparedStatement ps=cn.prepareStatement("INSERT INTO producto(id,nombre,categoria,unidad,stock_minimo) VALUES (?,?,?,?,?)")){ps.setString(1,p.getId());ps.setString(2,p.getNombre());ps.setString(3,p.getCategoria());ps.setString(4,p.getUnidad());ps.setBigDecimal(5,p.getStockMinimo());return ps.executeUpdate();}
 }
 public int actualizar(Connection cn,Producto p)throws SQLException {
  try(PreparedStatement ps=cn.prepareStatement("UPDATE producto SET nombre=?,categoria=?,unidad=?,stock_minimo=?,activo=?,version=version+1 WHERE id=? AND version=?")){ps.setString(1,p.getNombre());ps.setString(2,p.getCategoria());ps.setString(3,p.getUnidad());ps.setBigDecimal(4,p.getStockMinimo());ps.setBoolean(5,p.isActivo());ps.setString(6,p.getId());ps.setInt(7,p.getVersion());return ps.executeUpdate();}
 }
 private Producto mapear(ResultSet rs)throws SQLException {return new Producto(rs.getString("id"),rs.getString("nombre"),rs.getString("categoria"),rs.getString("unidad"),rs.getBigDecimal("stock_minimo"),rs.getBoolean("activo"),rs.getInt("version"));}
}
