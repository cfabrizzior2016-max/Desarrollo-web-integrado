package pe.edu.utp.bembos.config;
import com.zaxxer.hikari.*;
import java.sql.*;
import java.io.*;
import java.util.Properties;
public final class Conexion {
 private static HikariDataSource pool;
 private Conexion() {}
 public static synchronized void start() throws IOException {
  if(pool!=null) return;
  Properties p=new Properties(); String path=System.getProperty("bembos.config",System.getenv("BEMBOS_CONFIG"));
  if(path!=null) try(var in=new FileInputStream(path)){p.load(in);}
  HikariConfig c=new HikariConfig();
  c.setJdbcUrl(value("DB_URL",p,"db.url","jdbc:mysql://localhost:3306/bembos_invapp?connectionTimeZone=UTC"));
  c.setUsername(value("DB_USER",p,"db.user","bembos_app"));
  c.setPassword(value("DB_PASSWORD",p,"db.password",""));
  c.setDriverClassName("com.mysql.cj.jdbc.Driver");c.setMaximumPoolSize(8);c.setConnectionTimeout(5000);c.setInitializationFailTimeout(-1);
  pool=new HikariDataSource(c);
 }
 private static String value(String key,Properties p,String prop,String def){String v=System.getenv(key);return v==null?p.getProperty(prop,def):v;}
 public static Connection getConexion() throws SQLException {if(pool==null)throw new SQLException("Pool no iniciado");return pool.getConnection();}
 public static synchronized void stop(){if(pool!=null){pool.close();pool=null;}}
}