package pe.edu.utp.bembos;
import pe.edu.utp.bembos.service.*;
import pe.edu.utp.bembos.model.UsuarioSesion;
import com.google.gson.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.math.BigDecimal;
import java.nio.file.*;
import java.util.regex.Pattern;
class ValidationTest {
 @Test void demoPasswordMatchesRealSeed()throws Exception{
  var matcher=Pattern.compile("pbkdf2\\$600000\\$[^']+").matcher(Files.readString(Path.of("database/02_seed.sql")));assertTrue(matcher.find());String encoded=matcher.group();assertTrue(SeguridadContrasena.verify("Bembos2026!",encoded));assertFalse(SeguridadContrasena.verify("incorrecta",encoded));assertFalse(SeguridadContrasena.verify("Bembos2026!","broken"));
 }
 @Test void quantityRejectsNegativeAndOverflow(){assertThrows(ErrorNegocio.class,()->InventarioService.quantity(JsonParser.parseString("{\"n\":-1}").getAsJsonObject(),"n",false));assertThrows(ErrorNegocio.class,()->InventarioService.quantity(JsonParser.parseString("{\"n\":1000000000}").getAsJsonObject(),"n",false));}
 @Test void quantityHandlesDecimalAndMermaZero(){assertEquals(new BigDecimal("0.125"),InventarioService.quantity(JsonParser.parseString("{\"n\":0.125}").getAsJsonObject(),"n",true));assertThrows(ErrorNegocio.class,()->InventarioService.quantity(JsonParser.parseString("{\"n\":0}").getAsJsonObject(),"n",true));assertThrows(ErrorNegocio.class,()->InventarioService.quantity(JsonParser.parseString("{\"n\":0.0001}").getAsJsonObject(),"n",false));}
 @Test void roleIsCheckedInServer(){var u=new UsuarioSesion("u","Operario","a@b","OPERARIO","t");assertThrows(ErrorNegocio.class,()->InventarioService.role(u,"ADMINISTRADOR","JEFE_TIENDA"));}
}
