# Bembos InvApp para NetBeans

Proyecto Maven Java Web organizado como el ejemplo bootstrap-demo: `pom.xml`, configuración de NetBeans, paquetes Java, JSP y carpetas css/js. La raíz del paquete es **pe.edu.utp.bembos**. GitHub queda a cargo del grupo.

## Qué entregar

- Código fuente de este proyecto, comprimido.
- `docs/Documento_Tecnico_Bembos.docx` y su versión PDF.
- `docs/Presentacion_Bembos_NetBeans.pptx`, ocho diapositivas para una exposición de hasta 10 minutos.
- Scripts completos en `database/`: esquema, datos de demostración y usuario de conexión.
- URL real de GitHub, que el grupo añadirá al enviar la entrega.

## Requisitos

JDK **21**, NetBeans con soporte Java Web/Jakarta EE y Maven, MySQL **8.0.16+** (recomendado 8.4), Apache Tomcat **10.1** para la exposición permitida. Servidor alternativo elegido: **WildFly EE 10 41.0.1.Final**. Esa variante cumple Jakarta EE 10 con JDK 21. No elegir WildFly estándar 40/41, que corresponde a Jakarta EE 11.

El proyecto no requiere Node, npm, React ni Angular. Bootstrap 5.3.8 está incluido localmente. Las operaciones se ejecutan mediante servlet/JDBC, no mediante un simulador de datos.

## 1. Descomprimir y abrir en NetBeans

1. Extrae el ZIP en una carpeta de tu equipo.
2. En NetBeans usa **Archivo → Abrir proyecto**.
3. Selecciona la carpeta **bembos-invapp**, donde están `pom.xml`, `nb-configuration.xml`, `nbactions.xml` y `src`. No selecciones `src` ni el ZIP.
4. NetBeans lo reconoce como proyecto Maven con empaquetado WAR. No hace falta crear otro proyecto ni importar clases manualmente.
5. En **Herramientas → Plataformas Java** registra JDK 21. En **Propiedades del proyecto → Compilar** selecciona esa plataforma. Si aparece “Default”, comprueba que el JDK predeterminado sea 21.
6. En **Servicios → Servidores → Añadir servidor** registra Tomcat 10.1 y asígnale JDK 21.
7. En **Propiedades del proyecto → Ejecutar** selecciona ese Tomcat y contexto `/bembos-invapp`.

Si NetBeans no muestra la opción de servidores, habilita su soporte Java Web/Jakarta EE en Herramientas → Plugins. Los archivos compartidos configuran el tipo de proyecto y las acciones, pero la ruta del servidor y el JDK se eligen en cada computadora.

En el árbol del IDE, `src/main/java` aparece como **Paquetes de fuentes** y `src/main/webapp` como **Páginas web**. `target` se genera al compilar. No se incluye en el ZIP.

## 2. Crear la base de datos

En MySQL Workbench, usando una cuenta administradora, ejecuta una sola vez sobre una base nueva:

1. `database/01_schema.sql`
2. `database/02_seed.sql`
3. `database/03_usuario.sql`

El esquema crea **bembos_invapp** y 12 tablas. Cambia la clave del usuario `bembos_app` en el tercer script y usa la misma en la configuración. La aplicación no necesita conectarse como root. No ejecutes nuevamente el seed sobre datos ya creados.

## 3. Configurar MySQL desde NetBeans

Copia `config/db.properties.example` a **C:/bembos/db.properties**, fuera del repositorio. Ajusta URL, usuario y contraseña:

```properties
db.url=jdbc:mysql://localhost:3306/bembos_invapp?connectionTimeZone=UTC
db.user=bembos_app
db.password=TU_CLAVE_LOCAL
```

**Para Tomcat registrado en NetBeans:** detén el servidor y abre sus propiedades. En las opciones de plataforma/JVM agrega:

```text
-Dbembos.config=C:/bembos/db.properties
```

El nombre de la pestaña puede variar según la versión de NetBeans. La propiedad debe aplicarse a la JVM de **Tomcat**, no a la JVM de Maven. Si esa opción no aparece, define la variable de entorno **BEMBOS_CONFIG=C:/bembos/db.properties** en Windows, cierra y vuelve a abrir NetBeans para que la herede, y después inicia Tomcat desde el IDE.

También puedes utilizar `DB_URL`, `DB_USER`, `DB_PASSWORD` como variables de entorno del servidor. Tienen prioridad sobre el archivo. No copies credenciales al código Java ni las subas a GitHub.

Para iniciar Tomcat desde `startup.bat` puedes usar su `bin/setenv.bat`:

```bat
set "JAVA_HOME=C:\Program Files\Java\jdk-21"
set "CATALINA_OPTS=%CATALINA_OPTS% -Dbembos.config=C:/bembos/db.properties"
```

El arranque administrado por NetBeans puede no utilizar ese script, por eso se recomienda configurar la opción JVM del servidor o BEMBOS_CONFIG para el IDE.

## 4. Compilar y ejecutar

En NetBeans: clic derecho sobre el proyecto → **Limpiar y construir**, luego **Ejecutar**. La primera compilación descarga dependencias Maven. Abre:

**http://localhost:8080/bembos-invapp/**

La página inicial es `index.jsp`. El servlet principal está en `pe.edu.utp.bembos.controller.InventarioServlet`, mapeado a `/api/*`. No abras la JSP mediante doble clic en el explorador: necesita el servidor.

Desde terminal con JDK 21 y Maven:

```sh
mvn clean verify
```

El resultado es `target/bembos-invapp.war`. También se incluye un WAR ya compilado en `dist/`. Para desplegar manualmente, cópialo a `TOMCAT_HOME/webapps` con Tomcat detenido y después inicia el servidor.

## 5. Usuarios y recorrido de prueba

Contraseña de las cuentas académicas: **Bembos2026!**.

| Correo | Rol | Tienda |
|---|---|---|
| admin@bembos.demo | Administrador | Miraflores |
| jefe@bembos.demo | Jefe de tienda | Miraflores |
| operario@bembos.demo | Operario | Miraflores |
| otra@bembos.demo | Jefe de tienda | Central |

1. Administrador: consulta el catálogo, crea/edita un insumo y crea un lote.
2. Operario: registra una merma y comprueba el descuento de stock.
3. Operario: envía un conteo de todos los lotes activos. Cambia una cantidad para mostrar una diferencia.
4. Jefe: revisa el conteo. Aprobar ajusta el stock y cierra el turno. Observar exige un motivo y permite enviar otro conteo.
5. Jefe: consulta historial y abre un nuevo turno.

Si el stock cambió después de enviar el conteo, la aprobación devuelve 409 y conserva los valores previos. Se debe observar y recontar. Un reintento idéntico de merma/conteo con el mismo UUID no aplica la operación dos veces.

## 6. Servidor alternativo elegido

Se elige **WildFly EE 10 41.0.1.Final**, cuya variante EE 10 está documentada para Jakarta EE 10 y JDK 21. El sustento y la comparación con Payara, GlassFish y Tomcat están en el documento técnico.

Para probarlo sin NetBeans:

1. Descarga específicamente la distribución WildFly **EE 10**, no la estándar EE 11 ni Preview.
2. Configura JAVA_HOME a JDK 21 y BEMBOS_CONFIG al archivo de conexión.
3. Ejecuta `bin/standalone.bat` en Windows, o `bin/standalone.sh` en Linux.
4. Copia `dist/bembos-invapp.war` a `standalone/deployments` y espera el archivo marcador `.deployed`.
5. Abre el mismo contexto en el puerto 8080. Detén Tomcat antes para evitar conflictos de puerto.

La exposición solicitada se realiza en NetBeans y Tomcat. La selección de WildFly satisface el sustento del servidor alternativo; no se afirma que NetBeans ni WildFly hayan sido abiertos o ejecutados en esta validación.

## 7. Correspondencia con el ejemplo

| Elemento del ejemplo | Proyecto Bembos |
|---|---|
| pom.xml y WAR | Maven, JDK 21, Jakarta EE 10 |
| nb-configuration.xml | Identificación del perfil web y servidor Tomcat |
| Paquetes config/controller/dao/model | pe.edu.utp.bembos más esas capas |
| Conexion.java | Pool JDBC y configuración externa |
| Servlet | InventarioServlet |
| ProductoDAO y Producto | DAO tipado y modelo de insumo |
| JSP | index.jsp como vista de entrada |
| css/js | Bootstrap local, estilos y validaciones |
| META-INF/context.xml | Contexto /bembos-invapp |
| WEB-INF/web.xml | Servlet 6.0, sesión y JSP inicial |

El proyecto utiliza JDBC. No requiere `persistence.xml` ni unidad JPA, ni declara CDI que no esté usando. La capa `service` agrega reglas de negocio y transacciones a la organización del ejemplo.

## 8. Alcance y verificación

Implementados: sesión, roles, catálogo, lotes, conteos, mermas, alertas, revisión de cierres e historial por tienda. Pendientes del proyecto original: Android nativo, Room/SQLite, cola offline y sincronización con POS/ERP. Este avance web requiere conexión.

`docs/VERIFICACION.md` registra los resultados realmente ejecutados. El grupo debe hacer su demostración propia en NetBeans y añadir la URL de GitHub a la entrega.

## Errores comunes

- Proyecto no reconocido: selecciona la carpeta con pom.xml y comprueba el soporte Maven/Java Web.
- Error de Java: Maven y Tomcat deben usar **JDK 21**.
- 503 en login: comprueba MySQL, scripts, URL y credenciales en la configuración del servidor.
- 404: revisa el contexto, el nombre del WAR y el estado del despliegue.
- 403: verifica sesión, rol y token. Recarga la página si expiró.
- 409: revisa stock/versión o datos duplicados antes de reintentar.
