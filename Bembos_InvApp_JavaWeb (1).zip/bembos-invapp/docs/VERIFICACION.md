# Verificación del proyecto adaptado a NetBeans

Validación ejecutada el 13 de octubre de 2026 sobre MySQL de prueba.

## Resultados aprobados

- Maven con JDK 21.0.12: clean verify, BUILD SUCCESS y generación del WAR.
- JUnit: 4 pruebas, 0 errores, 0 fallos, 0 omisiones.
- MySQL 8.0.46: esquema de doce tablas, seed y usuario importados.
- WAR real desplegado en Tomcat embebido 10.1.60, con Jasper para compilar index.jsp.
- JSP inicial y Bootstrap local respondieron 200.
- Quince grupos de pruebas HTTP aprobados: login, roles, CSRF, tiendas, catálogo, conflicto de versión, lotes, merma concurrente/idempotente, rollback, escritura ajena, conteos, alertas, revisión, aprobación y turno/historial.
- Sintaxis JavaScript y declaraciones package bajo pe.edu.utp.bembos comprobadas.
- Documento Word/PDF y ocho diapositivas revisados mediante sus renders.

## Límites

No se abrió NetBeans ni se desplegó WildFly en esta validación. La estructura Maven WAR y la configuración compartida preparan el proyecto para seleccionar el JDK y servidor en cada computadora. No se realizaron pruebas visuales de la aplicación en un navegador real, pruebas de carga ni pruebas offline.

## Repetir pruebas

El script docs/integration_http.py modifica registros. Usar únicamente una instancia desechable recién cargada con esquema y seed. No usar datos reales ni una base alterada por una ejecución previa.

El perfil integration añade Tomcat y Jasper al classpath de prueba, sin empaquetarlos en el WAR:

```sh
mvn -Pintegration test-compile dependency:build-classpath -Dmdep.outputFile=target/test-classpath.txt
```

Compilar src/integration/java/pe/edu/utp/bembos/TestServer.java con el classpath generado más target/classes y target/test-classes. Ejecutar pe.edu.utp.bembos.TestServer desde la raíz del proyecto con MySQL de prueba configurado. Puerto de prueba: 18080. Separador de classpath: punto y coma en Windows, dos puntos en Linux.

```sh
python -m pip install requests
python docs/integration_http.py
```

Para JUnit basta mvn test. El grupo debe hacer el recorrido de README.md y EXPOSICION.md desde su NetBeans y Tomcat y registrar sus propias evidencias.
