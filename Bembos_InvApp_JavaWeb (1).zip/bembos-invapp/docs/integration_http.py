"""Prueba HTTP contra una BD desechable importada con el schema y seed.
Nunca ejecutar contra datos reales. Iniciar TestServer según VERIFICACION.md.
"""
import requests,uuid,concurrent.futures
BASE='http://localhost:18080/bembos-invapp/api'
checks=[]
root=requests.get(BASE[:-4]+'/',timeout=10)
assert root.status_code==200 and '<%@' not in root.text and 'css/bootstrap.min.css' in root.text
assert requests.get(BASE[:-4]+'/css/bootstrap.min.css',timeout=10).status_code==200
print('PASS vista JSP compilada y Bootstrap local')
def call(s,path,body=None,code=200):
 headers={'X-CSRF-Token':s.csrf} if body is not None else {}
 r=s.get(BASE+path) if body is None else s.post(BASE+path,json=body,headers=headers)
 assert r.status_code==code,(path,r.status_code,r.text)
 return r.json()
def login(email):
 s=requests.Session();s.csrf=call(s,'/me')['csrf'];r=call(s,'/login',{'correo':email,'password':'Bembos2026!'});s.csrf=r['csrf'];return s
def check(name):checks.append(name);print('PASS',name)
anon=requests.Session();anon.csrf=call(anon,'/me')['csrf'];call(anon,'/lotes',code=401);call(anon,'/login',{'correo':'admin@bembos.demo','password':'wrong'},401);check('autenticación y credenciales inválidas')
a=login('admin@bembos.demo');o=login('operario@bembos.demo');j=login('jefe@bembos.demo');other=login('otra@bembos.demo');check('login por los tres roles y otra tienda')
assert o.post(BASE+'/mermas',json={}).status_code==403;call(o,'/productos',{},403);call(o,'/historial?desde=2026-01-01&hasta=2030-01-01',code=403);check('CSRF y permisos en servidor')
assert len(call(other,'/lotes'))==1;assert len(call(o,'/lotes'))==4;check('aislamiento de tiendas')
p=call(a,'/productos',{'nombre':'Prueba HTTP','categoria':'Prueba','unidad':'kg','stock_minimo':'1'})['id'];prod=next(x for x in call(a,'/productos') if x['id']==p)
edit={'id':p,'nombre':'Prueba editada','categoria':'Prueba','unidad':'kg','stock_minimo':'2','activo':True,'version':prod['version']}
call(a,'/productos',edit);call(a,'/productos',edit,409);check('catálogo y conflicto de versión')
call(a,'/lotes',{'producto_id':p,'codigo':'HTTP-001','fecha_vencimiento':'2030-12-01','stock_actual':'3'});check('creación de lote')
t=call(o,'/turnos')[0]['id'];w={'id':str(uuid.uuid4()),'turno_id':t,'lote_id':'l-papa','cantidad':'1.250','motivo':'Daño','observacion':'Prueba HTTP'}
# Reintentos concurrentes con el mismo UUID deben descontar una sola vez.
with concurrent.futures.ThreadPoolExecutor(2) as pool: results=list(pool.map(lambda _:call(o,'/mermas',w),range(2)))
assert float(next(x for x in call(o,'/lotes') if x['id']=='l-papa')['stock_actual'])==11.25
wbad=dict(w,cantidad='2');call(o,'/mermas',wbad,409);check('merma transaccional e idempotencia concurrente')
call(o,'/mermas',dict(w,id=str(uuid.uuid4()),cantidad='1000'),409)
assert float(next(x for x in call(o,'/lotes') if x['id']=='l-papa')['stock_actual'])==11.25;check('stock negativo bloqueado con rollback')
call(o,'/mermas',dict(w,id=str(uuid.uuid4()),lote_id='l-otra'),404);check('escritura fuera de tienda bloqueada')
def count():
 rows=[x for x in call(o,'/lotes') if x['activo']];return {'id':str(uuid.uuid4()),'turno_id':t,'detalles':[{'lote_id':x['id'],'cantidad_contada':str(float(x['stock_actual'])-1 if x['id']=='l-carne' else x['stock_actual']),'version':x['version']} for x in rows]}
b=count();call(o,'/conteos',b);call(o,'/conteos',b);check('conteo y reintento sin duplicación')
assert any(x['tipo']=='DIFERENCIA' for x in call(j,'/alertas'));call(o,'/cierres',{'conteo_id':b['id'],'estado':'APROBADO'},403);call(other,'/cierres',{'conteo_id':b['id'],'estado':'APROBADO'},404);check('alertas y autorización del cierre')
call(o,'/mermas',dict(w,id=str(uuid.uuid4()),cantidad='0.500'))
call(j,'/cierres',{'conteo_id':b['id'],'estado':'APROBADO'},409);assert call(o,'/turnos');check('rechazo de aprobación con stock desactualizado')
call(j,'/cierres',{'conteo_id':b['id'],'estado':'OBSERVADO','observacion':'Recontar por movimiento posterior'})
b=count();call(o,'/conteos',b);call(j,'/cierres',{'conteo_id':b['id'],'estado':'APROBADO','observacion':'Verificado'});assert not call(o,'/turnos');assert float(next(x for x in call(o,'/lotes') if x['id']=='l-carne')['stock_actual'])==119;check('observación, nuevo conteo, aprobación y cierre de turno')
call(j,'/cierres',{'conteo_id':b['id'],'estado':'APROBADO'},409);call(o,'/mermas',dict(w,id=str(uuid.uuid4())),409);check('doble aprobación y operación sobre turno cerrado bloqueadas')
assert call(j,'/historial?desde=2020-01-01&hasta=2035-01-01');call(j,'/turnos',{});check('auditoría y reapertura de turno')
print(f'RESULTADO: {len(checks)} grupos de verificaciones HTTP aprobados')
