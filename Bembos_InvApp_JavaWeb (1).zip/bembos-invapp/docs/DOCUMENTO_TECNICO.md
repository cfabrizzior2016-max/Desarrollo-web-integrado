# Bembos InvApp Documento técnico

UNIVERSIDAD TECNOLÓGICA DEL PERÚ

Segundo avance del proyecto final




Bembos InvApp Java Web

Documento técnico

Sistema académico de control de inventario por tienda mediante JSP, servlets y MySQL. Este avance implementa catálogo, conteos, mermas y revisión de cierres con roles y trazabilidad.

El documento presenta la descripción del sistema, el modelo de datos, el script de creación, la arquitectura y los patrones implementados. También sustenta el servidor alternativo y describe el recorrido de ejecución para la exposición.

## Integrantes

Carlo Fabrizzio Rodriguez Rivero - U20202005

Samar Emilia Millones Gutarra - U22205197

Adiel Guillermo Pinto Ylasaca - U24212539

Lima, Perú
13 de octubre de 2026

## 1 Descripción del sistema

Bembos InvApp permite al personal de una tienda registrar y consultar sus operaciones de inventario. El catálogo identifica los insumos, sus unidades y el stock mínimo. Los lotes relacionan cada insumo con la tienda, el vencimiento y las existencias disponibles. Cada turno agrupa los conteos y las mermas realizados por usuarios autenticados.

La necesidad planteada en el primer avance es ordenar los registros y detectar diferencias entre las cantidades físicas y las registradas. El diagnóstico es una hipótesis académica y las pruebas utilizan datos simulados. La aplicación no tiene acceso a procesos internos ni a sistemas operativos reales de Bembos.

## 1 1 Objetivo y continuidad

Desarrollar un avance Java Web que permita gestionar el inventario, registrar mermas y revisar cierres de turno, manteniendo la trazabilidad por responsable y tienda. La propuesta conserva el dominio del primer avance. Para esta entrega cambia la plataforma Android y Oracle por navegador y MySQL, conforme a los requisitos de aplicaciones web.

## 1 2 Flujo de operación

El usuario inicia sesión y consulta los lotes de su tienda. Una merma válida descuenta stock al guardarse. El conteo registra cantidades físicas y diferencias. El jefe revisa el conteo: observar exige un motivo y mantiene el turno abierto; aprobar actualiza las cantidades y finaliza el turno. El historial conserva la operación y su actor.

## 1 3 Alcance de este avance

Se implementan autenticación, roles, catálogo, creación de lotes, turnos, conteos completos, mermas, alertas y consulta de historial. Quedan para etapas posteriores Android nativo, almacenamiento local, sincronización offline e integración POS/ERP. El sistema web necesita conexión al servidor y a MySQL.

## 2 Diagrama de base de datos

Figura 1. Acceso, catálogo e inventario por tienda. PK identifica una clave primaria, FK una clave foránea y UQ una restricción única. Las flechas van de la tabla padre a la dependiente. Estas entidades también participan en la segunda vista.

## 2 1 Operaciones y revisión del inventario

Figura 2. Relaciones de conteos, mermas, alertas, cierres e historial. Usuario, turno y lote son las mismas entidades de la figura 1. En detalle_conteo, registrada y contada resumen cantidad_registrada y cantidad_contada. El cierre es opcional y único por conteo; las demás relaciones son de uno a muchos, salvo la referencia opcional de alerta a conteo.

## 2 2 Tablas y reglas de integridad

Los identificadores son CHAR(36). Las cantidades usan DECIMAL(12,3), y en Java BigDecimal. Cada detalle conserva la cantidad registrada y la versión del lote, además de la cantidad física. Las claves foráneas aseguran la relación entre registros; el servicio valida rol, tienda, estado y disponibilidad.

Las alertas de stock mínimo usan la suma de los lotes de cada producto. Las de vencimiento se calculan al consultar, para lotes con stock y vencimiento en siete días o antes. Las diferencias pendientes se almacenan en alerta y se atienden cuando el jefe revisa el conteo.

## 3 Script de creación de base de datos

El script completo de creación se incluye en el anexo A y en database/01_schema.sql. Crea bembos_invapp con codificación utf8mb4, doce tablas, claves foráneas, restricciones CHECK, columnas generadas, índices y triggers de protección del historial. Requiere MySQL 8.0.16 o posterior para aplicar las restricciones CHECK.

Los scripts se ejecutan con una cuenta administradora en MySQL Workbench, sobre una base nueva. Los registros de demostración no deben volver a insertarse en una base ya poblada. La aplicación utiliza su propia cuenta de conexión con permisos SELECT, INSERT y UPDATE, y no requiere permisos de DROP.

## 3 1 Ejemplo de relación implementada

CREATE TABLE detalle_conteo (

  id CHAR(36) PRIMARY KEY,

  conteo_id CHAR(36) NOT NULL,

  lote_id CHAR(36) NOT NULL,

  cantidad_registrada DECIMAL(12,3) NOT NULL,

  cantidad_contada DECIMAL(12,3) NOT NULL,

  version_lote INT NOT NULL,

  diferencia DECIMAL(12,3) GENERATED ALWAYS AS

    (cantidad_contada-cantidad_registrada) STORED,

  FOREIGN KEY(conteo_id) REFERENCES conteo(id),

  FOREIGN KEY(lote_id) REFERENCES lote(id),

  UNIQUE(conteo_id,lote_id),

  CHECK(cantidad_registrada>=0),

  CHECK(cantidad_contada>=0)

 );

Este ejemplo pertenece al mismo esquema del anexo. La diferencia se calcula en MySQL. La versión conservada permite comprobar si un lote cambió después del conteo. Los datos iniciales y las fechas relativas del seed permiten demostrar alertas sin depender de registros reales.

## 4 Arquitectura del sistema

La arquitectura aplica MVC con una capa de servicios y persistencia JDBC. index.jsp representa la vista web. JavaScript envía operaciones JSON al controlador InventarioServlet. El servicio decide si la operación cumple las reglas de negocio y delimita la transacción. Los DAO ejecutan consultas parametrizadas y transforman resultados en objetos o mapas de consulta.

## 4 1 Transacciones de inventario

Una merma bloquea la tienda, el turno y el lote involucrado, comprueba el stock y registra el descuento junto con la merma y la auditoría. Si una validación falla, se revierte toda la operación. Los conteos y las mermas usan un UUID y comparan su contenido para que un reintento idéntico no se aplique dos veces.

Al aprobar, el servicio verifica las versiones de los lotes y el conjunto de lotes activos. Si hubo movimientos posteriores, devuelve un conflicto y conserva el inventario. Aprobar un conteo vigente ajusta los stocks y cierra el turno en una sola transacción. Observar permite enviar un conteo nuevo sin borrar la evidencia anterior.

## 4 2 Sesión y configuración

Las contraseñas utilizan PBKDF2-HMAC-SHA256 con salt y 600 000 iteraciones. El servidor cambia el identificador de sesión al iniciar sesión y exige token CSRF en cada POST. Los permisos se verifican en el servicio, aunque el usuario manipule el navegador. La conexión se configura fuera del código mediante BEMBOS_CONFIG o la propiedad bembos.config.

## 5 Patrones usados

Los patrones siguientes corresponden a responsabilidades identificables en el código entregado. La separación permite explicar el avance de aplicaciones web y persistencia visto hasta la unidad 2.

## 5 1 Ejemplo del patrón DAO

ProductoDAO.listar recibe una conexión de la capa de servicio y devuelve una lista de Producto. El DAO obtiene las columnas con ResultSet y construye el modelo. Crear y actualizar utilizan PreparedStatement. El servicio es dueño de la transacción; el DAO cierra sus statements y resultados sin cerrar esa conexión compartida.

## 5 2 Correspondencia con el proyecto de clase

La estructura conserva los paquetes config, controller, dao y model del ejemplo Maven Web y agrega service para las reglas de inventario. Todas las declaraciones package comienzan por pe.edu.utp.bembos. El proyecto incluye la configuración compartida de NetBeans y acciones de ejecución con empaquetado WAR. No utiliza JPA ni una unidad persistence.xml porque la persistencia implementada es JDBC.

La vista principal es JSP y usa Bootstrap local y JavaScript. La comunicación por JSON permite actualizar las tablas sin reconstruir cada pantalla en el servidor. Sigue siendo un proyecto Java Web desplegado en el contenedor y con las operaciones ejecutadas por el servlet.

## 6 Elección del servidor de aplicaciones

Se elige WildFly EE 10 41.0.1.Final para el servidor alternativo. La documentación oficial de la familia 41 declara compatibilidad de la variante EE 10 con Jakarta EE 10 sobre Java SE 21 [1]. Se especifica la variante porque WildFly estándar 40 y 41 utilizan Jakarta EE 11 [2].

## 6 1 Sustento de la elección

WildFly permite desplegar el archivo WAR y disponer de servicios de la plataforma Jakarta EE para una futura ampliación. La variante EE 10 evita modificar el nivel de API exigido. La aplicación conserva JDBC y su pool interno, por lo que el despliegue del avance no necesita una migración a JPA ni configurar un datasource administrado para funcionar.

La exposición de este segundo avance se mantiene en NetBeans con Tomcat 10.1, usando la excepción expresamente permitida. La documentación y el código distinguen esa demostración de la elección del servidor alternativo. El proyecto no acredita una ejecución en WildFly ni una prueba de carga.

## 6 2 Despliegue propuesto en WildFly

Descargar la distribución WildFly EE 10, configurar JAVA_HOME a JDK 21 y BEMBOS_CONFIG con la ruta de conexión. Iniciar standalone.bat, copiar el WAR a standalone/deployments y comprobar el marcador .deployed. Abrir /bembos-invapp/. Tomcat debe estar detenido si ambos usan el puerto 8080.

## 7 Ejecución en NetBeans

La carpeta bembos-invapp contiene pom.xml, nb-configuration.xml, nbactions.xml y src. Se abre con Archivo > Abrir proyecto, seleccionando esa carpeta. NetBeans reconoce el empaquetado WAR. El usuario registra JDK 21 y Tomcat 10.1 en su equipo y selecciona ese servidor en las propiedades de ejecución.

La configuración de MySQL corresponde a la JVM del servidor, no a las opciones de Maven. En el arranque administrado por NetBeans, el script setenv.bat puede no ser utilizado. README.md detalla las alternativas y los errores frecuentes.

## 7 1 Recorrido para la exposición

Iniciar como administrador y mostrar el catálogo. Cambiar a operario para registrar una merma y un conteo con diferencia. Iniciar como jefe para revisar las cantidades y aprobar el cierre. Finalmente, mostrar el historial y abrir un nuevo turno. La presentación propone un máximo de diez minutos y deja tiempo para enseñar el código de servlet, servicio y DAO.

Contraseña académica de las cuentas: Bembos2026! Los hashes se guardan en MySQL. El archivo de configuración con la clave local no debe publicarse en GitHub.

## 8 Verificación y entregables

La validación del avance se ejecutó el 13 de octubre de 2026 sobre una instancia MySQL de prueba. Se compiló el proyecto con JDK 21 y se desplegó el WAR real en Tomcat embebido, incluyendo la compilación de index.jsp mediante Jasper. La validación no equivale a haber abierto NetBeans en el equipo del grupo.

Las pruebas también cubrieron login, roles, aislamiento por tienda, alta de lote, conflicto de versión del catálogo, conteos, alertas, observación, aprobación, cierre y consulta de historial. Los resultados se conservan en VERIFICACION.md y el script de pruebas puede repetirse sobre una base desechable.

## 8 1 Entregables del segundo avance

El paquete incluye código fuente Maven, configuración de NetBeans, scripts SQL, WAR, documento técnico Word y PDF, diagramas y PowerPoint. El grupo publicará el repositorio GitHub y compartirá su URL real. No se ha creado una URL ficticia ni se ha publicado contenido en su cuenta.

## 8 2 Comprobaciones pendientes

El grupo debe ejecutar y presentar el proyecto en su NetBeans y Tomcat, y validar el servidor alternativo antes de su uso. No se realizaron pruebas visuales en un navegador real, pruebas de carga ni pruebas offline. Android, sincronización local y conexión a sistemas reales quedan fuera de este avance implementado.

## Referencias técnicas

[1] WildFly. WildFly 41 is released. 16 de julio de 2026.

https://www.wildfly.org/news/2026/07/16/WildFly-41-is-released/

[2] WildFly. Using the WildFly EE 10 Feature-pack.

https://www.wildfly.org/guides/wildfly-ee-10-feature-pack/

[3] Payara. Supported Platforms para Community 6.2025.1.

https://docs.payara.fish/community/docs/6.2025.1/General%20Info/Supported%20Platforms.html

[4] Eclipse Foundation. Jakarta EE 10 Compatible Products.

https://jakarta.ee/compatibility/certification/10/

[5] Apache Tomcat. Documentación Tomcat 10.1.

https://tomcat.apache.org/tomcat-10.1-doc/index.html

[6] WildFly. Downloads, distribución EE 10 41.0.1.Final.

https://www.wildfly.org/downloads/

Fuentes del proyecto: propuesta Bembos InvApp del primer avance, consigna del segundo avance y ejemplo bootstrap-demo proporcionados por el equipo. Las referencias técnicas sustentan compatibilidad y elección del servidor; no acreditan un despliegue externo.

## Anexo A Script completo de creación

Contenido de database/01_schema.sql. Se entrega también como archivo SQL para ejecutarlo sin copiar desde el documento.

-- MySQL 8.0.16+ / 8.4. Ejecutar como administrador, una sola vez en una BD nueva.

CREATE DATABASE IF NOT EXISTS bembos_invapp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE bembos_invapp;

CREATE TABLE rol(

  id CHAR(36) PRIMARY KEY,

  nombre VARCHAR(30) NOT NULL UNIQUE

);

CREATE TABLE tienda(

  id CHAR(36) PRIMARY KEY,

  nombre VARCHAR(100) NOT NULL

);

CREATE TABLE usuario(

  id CHAR(36) PRIMARY KEY,

  rol_id CHAR(36) NOT NULL,

  tienda_id CHAR(36) NOT NULL,

  nombre VARCHAR(100) NOT NULL,

  correo VARCHAR(150) NOT NULL UNIQUE,

  password_hash VARCHAR(255) NOT NULL,

  activo BOOLEAN NOT NULL DEFAULT TRUE,

  FOREIGN KEY(rol_id) REFERENCES rol(id),

  FOREIGN KEY(tienda_id) REFERENCES tienda(id)

);

CREATE TABLE producto(

  id CHAR(36) PRIMARY KEY,

  nombre VARCHAR(100) NOT NULL,

  categoria VARCHAR(50) NOT NULL,

  unidad VARCHAR(20) NOT NULL,

  stock_minimo DECIMAL(12,3) NOT NULL,

  activo BOOLEAN NOT NULL DEFAULT TRUE,

  version INT NOT NULL DEFAULT 1,

  CHECK(stock_minimo>=0)

);

CREATE TABLE lote(

  id CHAR(36) PRIMARY KEY,

  producto_id CHAR(36) NOT NULL,

  tienda_id CHAR(36) NOT NULL,

  codigo VARCHAR(50) NOT NULL,

  fecha_vencimiento DATE NOT NULL,

  stock_actual DECIMAL(12,3) NOT NULL,

  version INT NOT NULL DEFAULT 1,

  FOREIGN KEY(producto_id) REFERENCES producto(id),

  FOREIGN KEY(tienda_id) REFERENCES tienda(id),

  UNIQUE(tienda_id,producto_id,codigo),

  CHECK(stock_actual>=0)

);

CREATE TABLE turno(

  id CHAR(36) PRIMARY KEY,

  tienda_id CHAR(36) NOT NULL,

  inicio TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  fin TIMESTAMP NULL,

  estado VARCHAR(20) NOT NULL DEFAULT 'ABIERTO',

  tienda_abierta CHAR(36) GENERATED ALWAYS AS (CASE WHEN estado='ABIERTO' THEN tienda_id ELSE

    NULL END) STORED,

  UNIQUE(tienda_abierta),

  FOREIGN KEY(tienda_id) REFERENCES tienda(id),

  CHECK(estado IN ('ABIERTO','CERRADO'))

);

CREATE TABLE conteo(

  id CHAR(36) PRIMARY KEY,

  turno_id CHAR(36) NOT NULL,

  usuario_id CHAR(36) NOT NULL,

  fecha TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  estado VARCHAR(20) NOT NULL DEFAULT 'ENVIADO',

  FOREIGN KEY(turno_id) REFERENCES turno(id),

  FOREIGN KEY(usuario_id) REFERENCES usuario(id),

  CHECK(estado IN ('ENVIADO','OBSERVADO','APROBADO'))

);

CREATE TABLE detalle_conteo(

  id CHAR(36) PRIMARY KEY,

  conteo_id CHAR(36) NOT NULL,

  lote_id CHAR(36) NOT NULL,

  cantidad_registrada DECIMAL(12,3) NOT NULL,

  cantidad_contada DECIMAL(12,3) NOT NULL,

  version_lote INT NOT NULL,

  diferencia DECIMAL(12,3) GENERATED ALWAYS AS (cantidad_contada-cantidad_registrada) STORED,

  FOREIGN KEY(conteo_id) REFERENCES conteo(id),

  FOREIGN KEY(lote_id) REFERENCES lote(id),

  UNIQUE(conteo_id,lote_id),

  CHECK(cantidad_registrada>=0),

  CHECK(cantidad_contada>=0)

);

CREATE TABLE merma(

  id CHAR(36) PRIMARY KEY,

  turno_id CHAR(36) NOT NULL,

  usuario_id CHAR(36) NOT NULL,

  lote_id CHAR(36) NOT NULL,

  cantidad DECIMAL(12,3) NOT NULL,

  motivo VARCHAR(50) NOT NULL,

  observacion VARCHAR(300) NULL,

  fecha TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY(turno_id) REFERENCES turno(id),

  FOREIGN KEY(usuario_id) REFERENCES usuario(id),

  FOREIGN KEY(lote_id) REFERENCES lote(id),

  CHECK(cantidad>0)

);

CREATE TABLE alerta(

  id CHAR(36) PRIMARY KEY,

  lote_id CHAR(36) NOT NULL,

  conteo_id CHAR(36) NULL,

  tipo VARCHAR(20) NOT NULL,

  mensaje VARCHAR(300) NOT NULL,

  estado VARCHAR(20) NOT NULL DEFAULT 'PENDIENTE',

  FOREIGN KEY(lote_id) REFERENCES lote(id),

  FOREIGN KEY(conteo_id) REFERENCES conteo(id),

  CHECK(tipo IN ('STOCK','VENCIMIENTO','DIFERENCIA')),

  CHECK(estado IN ('PENDIENTE','ATENDIDA'))

);

CREATE TABLE cierre_inventario(

  id CHAR(36) PRIMARY KEY,

  conteo_id CHAR(36) NOT NULL UNIQUE,

  jefe_id CHAR(36) NOT NULL,

  estado VARCHAR(20) NOT NULL,

  observacion VARCHAR(300) NULL,

  fecha TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY(conteo_id) REFERENCES conteo(id),

  FOREIGN KEY(jefe_id) REFERENCES usuario(id),

  CHECK(estado IN ('APROBADO','OBSERVADO')),

  CHECK(estado!='OBSERVADO' OR CHAR_LENGTH(TRIM(observacion))>0)

);

CREATE TABLE historial_operaciones(

  id CHAR(36) PRIMARY KEY,

  usuario_id CHAR(36) NOT NULL,

  entidad VARCHAR(30) NOT NULL,

  id_entidad CHAR(36) NOT NULL,

  operacion VARCHAR(20) NOT NULL,

  antes JSON NULL,

  despues JSON NULL,

  fecha TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  FOREIGN KEY(usuario_id) REFERENCES usuario(id)

);

CREATE INDEX ix_hist_fecha ON historial_operaciones(fecha);

CREATE INDEX ix_lote_venc ON lote(tienda_id,fecha_vencimiento);

CREATE INDEX ix_conteo_turno ON conteo(turno_id,estado);

DELIMITER $$

CREATE TRIGGER historial_no_update BEFORE UPDATE ON historial_operaciones

FOR EACH ROW

BEGIN

  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Historial inmutable';

END$$

CREATE TRIGGER historial_no_delete BEFORE DELETE ON historial_operaciones

FOR EACH ROW

BEGIN

  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Historial inmutable';

END$$

DELIMITER ;