# Guion de exposición de Bembos InvApp

Presentación: Presentacion_Bembos_NetBeans.pptx. Ocho diapositivas con notas del expositor, para una exposición de hasta diez minutos.

| Tiempo | Diapositiva | Contenido |
|---|---|---|
| 0:00–0:30 | 1 | Proyecto y requisitos de plataforma. |
| 0:30–1:20 | 2 | Inventario por tienda y roles. |
| 1:20–2:10 | 3 | Relaciones de las doce tablas. |
| 2:10–2:40 | 4 | Scripts SQL. |
| 2:40–3:40 | 5 | Mostrar InventarioServlet, InventarioService y ProductoDAO. |
| 3:40–4:30 | 6 | Sustentar WildFly EE 10 y la excepción de Tomcat. |
| 4:30–5:00 | 7 | Mostrar Maven, JDK y servidor en NetBeans. |
| 5:00–9:30 | 8 | Demo: login, merma, conteo, aprobación e historial. |
| 9:30–10:00 | 8 | Pendientes y cierre. |

Antes de exponer: MySQL activo, scripts importados, conexión configurada, NetBeans con JDK 21 y Tomcat 10.1, y cuentas demo comprobadas. Abrir proyecto y navegador antes de comenzar. El grupo compartirá su URL real de GitHub.
