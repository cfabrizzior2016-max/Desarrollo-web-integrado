-- Cambiar esta clave local antes de ejecutar. Sin permisos de DROP ni DELETE de historial.
CREATE USER IF NOT EXISTS 'bembos_app'@'localhost' IDENTIFIED BY 'CambiarClaveLocal2026!';
GRANT SELECT, INSERT, UPDATE ON bembos_invapp.* TO 'bembos_app'@'localhost';
-- Docker requiere el host %. Crear ese usuario solo para la red local Docker.
